Portuguese Brasilian sentence checker for LibreOffice 

(developed by the Lightproof grammar checker extension generator,
see http://launchpad.net/lightproof)

2013 (c) Raimundo Santos Moura, license: MPL 1.1 / GPLv3+ / LGPLv3+

